
  # Guia Turístico

  This is a code bundle for Guia Turístico. The original project is available at https://www.figma.com/design/HrODdNqCY44BjAexT7oHQ4/Guia-Tur%C3%ADstico.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  