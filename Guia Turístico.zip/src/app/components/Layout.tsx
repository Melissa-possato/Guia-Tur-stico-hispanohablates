import { Outlet, Link, useLocation } from 'react-router';
import { Map, Shield, MessageCircle, Landmark, Route, Calendar, Menu, X } from 'lucide-react';
import { useState } from 'react';

export function Layout() {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navigation = [
    { name: 'Início', path: '/', icon: Map },
    { name: 'Mapa', path: '/mapa', icon: Map },
    { name: 'Sobrevivência', path: '/sobrevivencia', icon: Shield },
    { name: 'Frases Úteis', path: '/frases', icon: MessageCircle },
    { name: 'Guia Cultural', path: '/cultura', icon: Landmark },
    { name: 'Roteiros', path: '/roteiros', icon: Route },
    { name: 'Eventos', path: '/eventos', icon: Calendar },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center space-x-2">
              <Map className="h-8 w-8 text-blue-600" />
              <span className="text-xl font-bold text-gray-900">Guia Turístico</span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-1">
              {navigation.slice(1).map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center space-x-1 px-3 py-2 rounded-md transition-colors ${
                      isActive
                        ? 'bg-blue-50 text-blue-600'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span className="text-sm font-medium">{item.name}</span>
                  </Link>
                );
              })}
            </nav>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-md text-gray-700 hover:bg-gray-100"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden border-t border-gray-200 bg-white">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navigation.slice(1).map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center space-x-3 px-3 py-2 rounded-md ${
                      isActive
                        ? 'bg-blue-50 text-blue-600'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="font-medium">{item.name}</span>
                  </Link>
                );
              })}
            </div>
          </nav>
        )}
      </header>

      {/* Main Content */}
      <main>
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-bold mb-3">Guia Turístico</h3>
              <p className="text-gray-400 text-sm">
                Seu companheiro perfeito para explorar a cidade com confiança e estilo.
              </p>
            </div>
            <div>
              <h3 className="font-bold mb-3">Links Rápidos</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/mapa" className="text-gray-400 hover:text-white">Mapa</Link></li>
                <li><Link to="/sobrevivencia" className="text-gray-400 hover:text-white">Modo Sobrevivência</Link></li>
                <li><Link to="/eventos" className="text-gray-400 hover:text-white">Eventos</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-3">Contato</h3>
              <p className="text-gray-400 text-sm">
                contato@guiaturistico.com<br />
                +55 (11) 1234-5678
              </p>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-6 text-center text-sm text-gray-400">
            © 2026 Guia Turístico. Todos os direitos reservados.
          </div>
        </div>
      </footer>
    </div>
  );
}
