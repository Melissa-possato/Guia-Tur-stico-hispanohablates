import { BookOpen, Music, Utensils, Users, Calendar, Sparkles } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export function CulturalGuide() {
  const culturalTopics = [
    {
      icon: BookOpen,
      title: 'História',
      color: 'bg-purple-500',
      content: [
        'A cidade foi fundada em 1554 por exploradores europeus',
        'Centro importante durante o período colonial',
        'Preserva arquitetura histórica dos séculos XVII e XVIII',
        'Tombada como patrimônio histórico em 1985',
      ],
    },
    {
      icon: Users,
      title: 'Costumes Locais',
      color: 'bg-green-500',
      content: [
        'Cumprimentar com beijo no rosto é comum entre conhecidos',
        'Pontualidade é valorizada em compromissos profissionais',
        'Gorjeta de 10% é esperada em restaurantes',
        'Tirar sapatos ao entrar em casas é uma cortesia apreciada',
      ],
    },
    {
      icon: Utensils,
      title: 'Culinária Típica',
      color: 'bg-orange-500',
      content: [
        'Feijoada - prato tradicional servido às quartas e sábados',
        'Acarajé - bolinho de feijão frito típico da região',
        'Churrasco - tradição gastronômica muito apreciada',
        'Brigadeiro - doce típico presente em todas as celebrações',
      ],
    },
    {
      icon: Music,
      title: 'Arte e Música',
      color: 'bg-pink-500',
      content: [
        'Samba e Bossa Nova são gêneros musicais nascidos aqui',
        'Forte tradição em arte de rua e grafite',
        'Festivais de música acontecem durante todo o ano',
        'Teatro e dança contemporânea muito valorizados',
      ],
    },
    {
      icon: Calendar,
      title: 'Festividades',
      color: 'bg-green-500',
      content: [
        'Carnaval - maior celebração do ano (fevereiro/março)',
        'Festa Junina - celebração das festas de São João (junho)',
        'Reveillon - virada de ano com grandes eventos',
        'Festivais culturais mensais nos principais parques',
      ],
    },
    {
      icon: Sparkles,
      title: 'Etiqueta Social',
      color: 'bg-yellow-500',
      content: [
        'Brasileiros são conhecidos pela hospitalidade calorosa',
        'Conversas em voz alta são normais e não indicam conflito',
        'Evite discutir política em ambientes sociais',
        'Respeite filas e aguarde sua vez pacientemente',
      ],
    },
  ];

  const mustsKnow = [
    {
      title: 'Idioma',
      description: 'Português é o idioma oficial. Inglês é falado em áreas turísticas, mas aprender algumas frases básicas é muito apreciado.',
    },
    {
      title: 'Moeda',
      description: 'Real (R$) é a moeda oficial. Casas de câmbio e bancos oferecem serviços de troca. Cartões são amplamente aceitos.',
    },
    {
      title: 'Clima',
      description: 'Tropical durante a maior parte do ano. Verão: dezembro a março (quente e úmido). Inverno: junho a setembro (ameno).',
    },
    {
      title: 'Horários',
      description: 'Lojas: 9h-18h. Shoppings: 10h-22h. Restaurantes: 11h-23h. Bancos: 10h-16h (dias úteis).',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Guia Cultural</h1>
        <p className="text-gray-600">Descubra a história, tradições e costumes locais</p>
      </div>

      {/* Hero Image */}
      <div className="mb-8 rounded-lg overflow-hidden shadow-lg">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1680144653445-9ea91934e5d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdWx0dXJhbCUyMGhlcml0YWdlJTIwbXVzZXVtfGVufDF8fHx8MTc3MjEyODI3NXww&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Patrimônio cultural"
          className="w-full h-80 object-cover"
        />
      </div>

      {/* Cultural Topics Grid */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Aspectos Culturais</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {culturalTopics.map((topic) => {
            const Icon = topic.icon;
            return (
              <div key={topic.title} className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow p-6">
                <div className="flex items-center mb-4">
                  <div className={`${topic.color} w-10 h-10 rounded-lg flex items-center justify-center mr-3`}>
                    <Icon className="h-5 w-5 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900">{topic.title}</h3>
                </div>
                <ul className="space-y-2">
                  {topic.content.map((item, index) => (
                    <li key={index} className="flex items-start text-sm text-gray-600">
                      <span className="inline-block w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </div>

      {/* Must Know Section */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Informações Essenciais</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {mustsKnow.map((item) => (
            <div key={item.title} className="bg-gradient-to-br from-green-50 to-purple-50 rounded-lg p-6">
              <h3 className="font-bold text-lg text-gray-900 mb-2">{item.title}</h3>
              <p className="text-gray-700 text-sm leading-relaxed">{item.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Cultural Do's and Don'ts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-green-50 rounded-lg p-6 border border-green-200">
          <h3 className="font-bold text-lg text-green-900 mb-4">✓ Faça</h3>
          <ul className="space-y-2 text-sm text-green-800">
            <li>• Seja amigável e aberto a conversas</li>
            <li>• Experimente a culinária local</li>
            <li>• Respeite as tradições e costumes</li>
            <li>• Aprenda algumas palavras em português</li>
            <li>• Vista-se adequadamente para locais religiosos</li>
            <li>• Peça permissão antes de fotografar pessoas</li>
          </ul>
        </div>

        <div className="bg-red-50 rounded-lg p-6 border border-red-200">
          <h3 className="font-bold text-lg text-red-900 mb-4">✗ Evite</h3>
          <ul className="space-y-2 text-sm text-red-800">
            <li>• Comparar negativamente com seu país de origem</li>
            <li>• Levantar a voz em discussões</li>
            <li>• Demonstrar impaciência com diferenças culturais</li>
            <li>• Vestir roupas muito reveladoras em áreas conservadoras</li>
            <li>• Recusar comida oferecida de forma grosseira</li>
            <li>• Ignorar os costumes locais de cumprimento</li>
          </ul>
        </div>
      </div>

      {/* Cultural Immersion Tips */}
      <div className="mt-8 bg-gradient-to-r from-purple-600 to-green-600 rounded-lg p-6 text-white">
        <h3 className="font-bold text-lg mb-3">Dica de Imersão Cultural</h3>
        <p className="text-purple-100 mb-4">
          A melhor maneira de conhecer a cultura local é participar de eventos comunitários e conversar com os moradores. 
          Visite mercados locais, assista a apresentações de música ao vivo e não tenha medo de sair da zona de conforto turística.
        </p>
        <div className="flex flex-wrap gap-2">
          <span className="px-3 py-1 bg-white/20 rounded-full text-sm">Mercados Locais</span>
          <span className="px-3 py-1 bg-white/20 rounded-full text-sm">Música ao Vivo</span>
          <span className="px-3 py-1 bg-white/20 rounded-full text-sm">Festivais</span>
          <span className="px-3 py-1 bg-white/20 rounded-full text-sm">Culinária de Rua</span>
        </div>
      </div>
    </div>
  );
}