import { useState } from 'react';
import { Calendar as CalendarIcon, MapPin, Clock, Tag, Search, Filter, ChevronLeft, ChevronRight } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export function EventsCalendar() {
  const [selectedCategory, setSelectedCategory] = useState('todos');
  const [currentMonth, setCurrentMonth] = useState(new Date(2026, 1)); // Fevereiro 2026

  const categories = [
    { id: 'todos', name: 'Todos', color: 'bg-gray-500' },
    { id: 'musica', name: 'Música', color: 'bg-purple-500' },
    { id: 'arte', name: 'Arte', color: 'bg-pink-500' },
    { id: 'gastronomia', name: 'Gastronomia', color: 'bg-orange-500' },
    { id: 'esportes', name: 'Esportes', color: 'bg-blue-500' },
    { id: 'cultura', name: 'Cultura', color: 'bg-green-500' },
  ];

  const events = [
    {
      id: 1,
      title: 'Festival de Jazz',
      category: 'musica',
      date: '28 de Fevereiro',
      time: '19:00',
      location: 'Teatro Municipal',
      price: 'R$ 80 - R$ 150',
      description: 'Noite especial com grandes nomes do jazz nacional e internacional.',
      featured: true,
    },
    {
      id: 2,
      title: 'Feira de Arte Contemporânea',
      category: 'arte',
      date: '1-7 de Março',
      time: '10:00 - 20:00',
      location: 'Centro de Exposições',
      price: 'Gratuito',
      description: 'Mais de 100 artistas expondo suas obras. Vernissage na sexta às 19h.',
      featured: true,
    },
    {
      id: 3,
      title: 'Corrida da Cidade',
      category: 'esportes',
      date: '5 de Março',
      time: '7:00',
      location: 'Parque Central',
      price: 'R$ 50',
      description: 'Corrida de 5km e 10km. Inscrições abertas até 1º de março.',
      featured: false,
    },
    {
      id: 4,
      title: 'Festival Gastronômico',
      category: 'gastronomia',
      date: '10-15 de Março',
      time: '12:00 - 22:00',
      location: 'Praça da Gastronomia',
      price: 'Entrada gratuita',
      description: 'Degustação de pratos de 50+ restaurantes da cidade.',
      featured: true,
    },
    {
      id: 5,
      title: 'Show de Rock Nacional',
      category: 'musica',
      date: '12 de Março',
      time: '21:00',
      location: 'Arena Concert Hall',
      price: 'R$ 100 - R$ 200',
      description: 'Grandes bandas nacionais em uma noite inesquecível.',
      featured: false,
    },
    {
      id: 6,
      title: 'Semana Cultural',
      category: 'cultura',
      date: '17-23 de Março',
      time: 'Variado',
      location: 'Diversos locais',
      price: 'Gratuito',
      description: 'Programação especial com teatro, dança, música e workshops.',
      featured: false,
    },
    {
      id: 7,
      title: 'Exposição de Fotografia',
      category: 'arte',
      date: '20-30 de Março',
      time: '9:00 - 18:00',
      location: 'Museu de Arte',
      price: 'R$ 20',
      description: 'Retrospectiva de fotógrafos brasileiros dos últimos 50 anos.',
      featured: false,
    },
    {
      id: 8,
      title: 'Torneio de Futebol',
      category: 'esportes',
      date: '25 de Março',
      time: '15:00',
      location: 'Estádio Municipal',
      price: 'R$ 30 - R$ 80',
      description: 'Final do campeonato regional com entrada para toda família.',
      featured: false,
    },
  ];

  const filteredEvents = selectedCategory === 'todos'
    ? events
    : events.filter(event => event.category === selectedCategory);

  const featuredEvents = events.filter(event => event.featured);

  const monthNames = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  const changeMonth = (direction: number) => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + direction));
  };

  const getCategoryColor = (categoryId: string) => {
    return categories.find(cat => cat.id === categoryId)?.color || 'bg-gray-500';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Calendário de Eventos</h1>
        <p className="text-gray-600">Descubra os melhores eventos acontecendo na cidade</p>
      </div>

      {/* Search and Filter */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar eventos..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <button className="flex items-center justify-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            <Filter className="h-5 w-5" />
            <span>Filtros</span>
          </button>
        </div>
      </div>

      {/* Month Navigation */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="flex items-center justify-between">
          <button
            onClick={() => changeMonth(-1)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ChevronLeft className="h-5 w-5 text-gray-600" />
          </button>
          <div className="text-center">
            <h2 className="text-xl font-bold text-gray-900">
              {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
            </h2>
          </div>
          <button
            onClick={() => changeMonth(1)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ChevronRight className="h-5 w-5 text-gray-600" />
          </button>
        </div>
      </div>

      {/* Featured Events */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Eventos em Destaque</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredEvents.map((event) => (
            <div key={event.id} className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative h-48 bg-gradient-to-br from-blue-400 to-purple-500">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1703300450387-047da16a89c4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWxlbmRhciUyMGV2ZW50cyUyMHBsYW5uZXJ8ZW58MXx8fHwxNzcyMTI4Mjc1fDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt={event.title}
                  className="w-full h-full object-cover opacity-80"
                />
                <div className="absolute top-3 right-3">
                  <span className={`${getCategoryColor(event.category)} text-white text-xs px-3 py-1 rounded-full`}>
                    {categories.find(cat => cat.id === event.category)?.name}
                  </span>
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-lg text-gray-900 mb-2">{event.title}</h3>
                <div className="space-y-1 text-sm text-gray-600 mb-3">
                  <div className="flex items-center">
                    <CalendarIcon className="h-4 w-4 mr-2 text-gray-400" />
                    <span>{event.date}</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-2 text-gray-400" />
                    <span>{event.time}</span>
                  </div>
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-2 text-gray-400" />
                    <span>{event.location}</span>
                  </div>
                </div>
                <button className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium text-sm">
                  Ver Detalhes
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Category Filter */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`px-4 py-2 rounded-full whitespace-nowrap transition-colors ${
              selectedCategory === category.id
                ? `${category.color} text-white`
                : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
            }`}
          >
            {category.name}
          </button>
        ))}
      </div>

      {/* All Events List */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Todos os Eventos</h2>
        <div className="space-y-4">
          {filteredEvents.map((event) => (
            <div key={event.id} className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-xl font-bold text-gray-900">{event.title}</h3>
                    <span className={`${getCategoryColor(event.category)} text-white text-xs px-3 py-1 rounded-full ml-2`}>
                      {categories.find(cat => cat.id === event.category)?.name}
                    </span>
                  </div>
                  <p className="text-gray-600 text-sm mb-3">{event.description}</p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm text-gray-600">
                    <div className="flex items-center">
                      <CalendarIcon className="h-4 w-4 mr-2 text-gray-400" />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2 text-gray-400" />
                      <span>{event.time}</span>
                    </div>
                    <div className="flex items-center">
                      <Tag className="h-4 w-4 mr-2 text-gray-400" />
                      <span>{event.price}</span>
                    </div>
                  </div>
                  <div className="flex items-center mt-2 text-sm text-gray-600">
                    <MapPin className="h-4 w-4 mr-2 text-gray-400" />
                    <span>{event.location}</span>
                  </div>
                </div>
                <div className="flex md:flex-col gap-2 md:w-32">
                  <button className="flex-1 md:flex-none px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium text-sm">
                    Ingressos
                  </button>
                  <button className="flex-1 md:flex-none px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium text-sm">
                    Salvar
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Newsletter Subscription */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white">
        <h3 className="font-bold text-lg mb-2">Não Perca Nenhum Evento!</h3>
        <p className="text-blue-100 text-sm mb-4">
          Inscreva-se na nossa newsletter e receba novidades sobre eventos diretamente no seu email.
        </p>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="email"
            placeholder="Seu melhor email"
            className="flex-1 px-4 py-2 rounded-lg text-gray-900 focus:ring-2 focus:ring-white focus:outline-none"
          />
          <button className="px-6 py-2 bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-colors font-medium">
            Inscrever-se
          </button>
        </div>
      </div>
    </div>
  );
}
