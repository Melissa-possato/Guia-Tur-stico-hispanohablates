import { Link } from 'react-router';
import { Map, Shield, MessageCircle, Landmark, Route, Calendar, ArrowRight } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export function Home() {
  const features = [
    {
      icon: Map,
      title: 'Mapa da Cidade',
      description: 'Explore os principais pontos turísticos e navegue pela cidade com facilidade.',
      path: '/mapa',
      color: 'bg-blue-500',
    },
    {
      icon: Shield,
      title: 'Modo Sobrevivência',
      description: 'Dicas essenciais de segurança, saúde e informações de emergência.',
      path: '/sobrevivencia',
      color: 'bg-red-500',
    },
    {
      icon: MessageCircle,
      title: 'Frases Úteis',
      description: 'Aprenda expressões essenciais para se comunicar durante sua viagem.',
      path: '/frases',
      color: 'bg-green-500',
    },
    {
      icon: Landmark,
      title: 'Guia Cultural',
      description: 'Descubra a história, tradições e costumes locais.',
      path: '/cultura',
      color: 'bg-purple-500',
    },
    {
      icon: Route,
      title: 'Roteiros',
      description: 'Roteiros personalizados para aproveitar ao máximo sua visita.',
      path: '/roteiros',
      color: 'bg-orange-500',
    },
    {
      icon: Calendar,
      title: 'Calendário de Eventos',
      description: 'Fique por dentro dos eventos e atividades acontecendo na cidade.',
      path: '/eventos',
      color: 'bg-pink-500',
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[500px] bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="absolute inset-0 bg-black opacity-40"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div className="max-w-2xl">
            <h1 className="text-5xl font-bold mb-4">
              Explore a Cidade com Confiança
            </h1>
            <p className="text-xl mb-8 text-blue-100">
              Seu guia completo com mapas, dicas culturais, frases úteis e muito mais para uma experiência inesquecível.
            </p>
            <Link
              to="/mapa"
              className="inline-flex items-center px-6 py-3 bg-white text-blue-600 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
            >
              Começar a Explorar
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Tudo que Você Precisa em Um Só Lugar
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Ferramentas e recursos para tornar sua viagem mais fácil, segura e enriquecedora.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <Link
                key={feature.path}
                to={feature.path}
                className="group bg-white rounded-xl shadow-sm hover:shadow-lg transition-shadow p-6 border border-gray-100"
              >
                <div className={`${feature.color} w-12 h-12 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600 mb-4">
                  {feature.description}
                </p>
                <div className="flex items-center text-blue-600 font-medium group-hover:translate-x-1 transition-transform">
                  Explorar
                  <ArrowRight className="ml-1 h-4 w-4" />
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Quick Tips Section */}
      <section className="bg-gray-100 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="font-bold text-lg mb-3 text-gray-900">Dica Rápida</h3>
              <p className="text-gray-600 text-sm">
                Sempre tenha um mapa offline disponível. Baixe as áreas que você planeja visitar antes de sair.
              </p>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="font-bold text-lg mb-3 text-gray-900">Horário de Funcionamento</h3>
              <p className="text-gray-600 text-sm">
                A maioria dos museus fecha às segundas-feiras. Planeje sua visita com antecedência.
              </p>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="font-bold text-lg mb-3 text-gray-900">Transporte Local</h3>
              <p className="text-gray-600 text-sm">
                O transporte público funciona das 5h às 23h. Considere táxis ou aplicativos para horários noturnos.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
