import { useState } from 'react';
import { MapPin, Navigation, Search, Star } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export function MapPage() {
  const [selectedCategory, setSelectedCategory] = useState('todos');

  const categories = [
    { id: 'todos', name: 'Todos', count: 24 },
    { id: 'monumentos', name: 'Monumentos', count: 8 },
    { id: 'museus', name: 'Museus', count: 6 },
    { id: 'restaurantes', name: 'Restaurantes', count: 5 },
    { id: 'parques', name: 'Parques', count: 5 },
  ];

  const locations = [
    {
      id: 1,
      name: 'Catedral Metropolitana',
      category: 'monumentos',
      rating: 4.8,
      distance: '0.5 km',
      description: 'Impressionante catedral do século XVIII com arquitetura barroca.',
      hours: '9:00 - 18:00',
    },
    {
      id: 2,
      name: 'Museu de Arte Moderna',
      category: 'museus',
      rating: 4.6,
      distance: '1.2 km',
      description: 'Coleção abrangente de arte contemporânea local e internacional.',
      hours: '10:00 - 19:00',
    },
    {
      id: 3,
      name: 'Parque Central',
      category: 'parques',
      rating: 4.7,
      distance: '0.8 km',
      description: 'Grande parque urbano com lagos, trilhas e áreas de piquenique.',
      hours: '6:00 - 22:00',
    },
    {
      id: 4,
      name: 'Restaurante Casa Velha',
      category: 'restaurantes',
      rating: 4.9,
      distance: '0.3 km',
      description: 'Culinária tradicional em ambiente histórico e aconchegante.',
      hours: '12:00 - 23:00',
    },
    {
      id: 5,
      name: 'Torre do Relógio',
      category: 'monumentos',
      rating: 4.5,
      distance: '1.5 km',
      description: 'Marco histórico com vista panorâmica da cidade.',
      hours: '10:00 - 17:00',
    },
    {
      id: 6,
      name: 'Museu Histórico',
      category: 'museus',
      rating: 4.4,
      distance: '1.8 km',
      description: 'Explore a rica história da cidade através de artefatos e exposições.',
      hours: '9:00 - 17:00',
    },
  ];

  const filteredLocations = selectedCategory === 'todos' 
    ? locations 
    : locations.filter(loc => loc.category === selectedCategory);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Mapa da Cidade</h1>
        <p className="text-gray-600">Descubra os melhores lugares para visitar</p>
      </div>

      {/* Search and Filter */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar por lugares..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>
          <button className="flex items-center justify-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            <Navigation className="h-5 w-5" />
            <span>Minha Localização</span>
          </button>
        </div>
      </div>

      {/* Categories */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`px-4 py-2 rounded-full whitespace-nowrap transition-colors ${
              selectedCategory === category.id
                ? 'bg-green-600 text-white'
                : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
            }`}
          >
            {category.name} ({category.count})
          </button>
        ))}
      </div>

      {/* Map Display */}
      <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
        <div className="relative h-96 bg-gray-200">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1722082839841-45473f5a15cf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b3VyaXN0JTIwY2l0eSUyMG1hcCUyMGFlcmlhbHxlbnwxfHx8fDE3NzIxMjgyNzR8MA&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Mapa da cidade"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="bg-white px-4 py-2 rounded-lg shadow-lg">
              <p className="text-sm text-gray-600">Mapa Interativo</p>
            </div>
          </div>
        </div>
      </div>

      {/* Locations List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredLocations.map((location) => (
          <div key={location.id} className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow overflow-hidden">
            <div className="p-6">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-gray-900 mb-1">{location.name}</h3>
                  <div className="flex items-center space-x-3 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-500 fill-current mr-1" />
                      <span>{location.rating}</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      <span>{location.distance}</span>
                    </div>
                  </div>
                </div>
                <span className="px-3 py-1 bg-green-50 text-green-700 text-xs rounded-full capitalize">
                  {location.category}
                </span>
              </div>
              
              <p className="text-gray-600 text-sm mb-3">{location.description}</p>
              
              <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                <span className="text-sm text-gray-500">
                  Horário: {location.hours}
                </span>
                <button className="text-green-600 hover:text-green-700 font-medium text-sm">
                  Ver no mapa
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}