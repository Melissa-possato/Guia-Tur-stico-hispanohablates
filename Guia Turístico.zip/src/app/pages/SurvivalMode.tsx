import { Phone, MapPin, Heart, AlertTriangle, Shield, Info } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export function SurvivalMode() {
  const emergencyContacts = [
    { service: 'Polícia', number: '190', icon: Shield },
    { service: 'Bombeiros', number: '193', icon: AlertTriangle },
    { service: 'Ambulância', number: '192', icon: Heart },
    { service: 'Defesa Civil', number: '199', icon: Info },
  ];

  const safetyTips = [
    {
      title: 'Documentos',
      tips: [
        'Mantenha cópias de documentos em local separado dos originais',
        'Tenha fotos digitais de passaporte e documentos importantes',
        'Deixe cópia dos documentos com alguém de confiança em casa',
      ],
    },
    {
      title: 'Dinheiro e Cartões',
      tips: [
        'Não carregue todo o dinheiro em um único lugar',
        'Informe seu banco sobre a viagem para evitar bloqueios',
        'Anote os números para bloqueio de cartões',
      ],
    },
    {
      title: 'Segurança Pessoal',
      tips: [
        'Evite exibir objetos de valor em público',
        'Prefira táxis oficiais ou aplicativos conhecidos',
        'Mantenha-se em áreas bem iluminadas à noite',
      ],
    },
    {
      title: 'Saúde',
      tips: [
        'Leve medicamentos de uso contínuo em quantidade suficiente',
        'Beba sempre água engarrafada',
        'Mantenha um kit de primeiros socorros básico',
      ],
    },
  ];

  const importantLocations = [
    {
      name: 'Hospital Central',
      address: 'Av. Principal, 1234',
      hours: '24 horas',
      phone: '(11) 3333-4444',
    },
    {
      name: 'Delegacia de Turismo',
      address: 'Rua do Comércio, 567',
      hours: '8:00 - 18:00',
      phone: '(11) 3333-5555',
    },
    {
      name: 'Farmácia 24h',
      address: 'Praça Central, 89',
      hours: '24 horas',
      phone: '(11) 3333-6666',
    },
    {
      name: 'Consulado Brasileiro',
      address: 'Av. Internacional, 2000',
      hours: '9:00 - 17:00',
      phone: '(11) 3333-7777',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Modo Sobrevivência</h1>
        <p className="text-gray-600">Informações essenciais para sua segurança e bem-estar</p>
      </div>

      {/* Emergency Alert */}
      <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-8 rounded-r-lg">
        <div className="flex items-start">
          <AlertTriangle className="h-6 w-6 text-red-500 mt-0.5 mr-3 flex-shrink-0" />
          <div>
            <h3 className="font-bold text-red-800 mb-1">Em caso de emergência</h3>
            <p className="text-sm text-red-700">
              Mantenha a calma e ligue para os números de emergência abaixo. Sempre informe sua localização exata.
            </p>
          </div>
        </div>
      </div>

      {/* Emergency Contacts */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Contatos de Emergência</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {emergencyContacts.map((contact) => {
            const Icon = contact.icon;
            return (
              <div key={contact.service} className="bg-white rounded-lg shadow-sm p-6 text-center hover:shadow-md transition-shadow">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-red-100 rounded-full mb-3">
                  <Icon className="h-6 w-6 text-red-600" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">{contact.service}</h3>
                <a
                  href={`tel:${contact.number}`}
                  className="text-2xl font-bold text-red-600 hover:text-red-700"
                >
                  {contact.number}
                </a>
              </div>
            );
          })}
        </div>
      </div>

      {/* Visual Banner */}
      <div className="mb-8 rounded-lg overflow-hidden">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1765996796562-ce301df337a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXJ2aXZhbCUyMGtpdCUyMGVtZXJnZW5jeXxlbnwxfHx8fDE3NzIxMjgyNzR8MA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Kit de sobrevivência"
          className="w-full h-64 object-cover"
        />
      </div>

      {/* Safety Tips */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Dicas de Segurança</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {safetyTips.map((section) => (
            <div key={section.title} className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-3">{section.title}</h3>
              <ul className="space-y-2">
                {section.tips.map((tip, index) => (
                  <li key={index} className="flex items-start text-sm text-gray-600">
                    <span className="inline-block w-1.5 h-1.5 bg-green-600 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Important Locations */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Locais Importantes</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {importantLocations.map((location) => (
            <div key={location.name} className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
              <h3 className="font-bold text-gray-900 mb-3">{location.name}</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-start">
                  <MapPin className="h-4 w-4 text-gray-400 mt-0.5 mr-2 flex-shrink-0" />
                  <span className="text-gray-600">{location.address}</span>
                </div>
                <div className="flex items-center">
                  <Info className="h-4 w-4 text-gray-400 mr-2 flex-shrink-0" />
                  <span className="text-gray-600">{location.hours}</span>
                </div>
                <div className="flex items-center">
                  <Phone className="h-4 w-4 text-gray-400 mr-2 flex-shrink-0" />
                  <a href={`tel:${location.phone}`} className="text-green-600 hover:text-green-700">
                    {location.phone}
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Additional Info */}
      <div className="mt-8 bg-green-50 rounded-lg p-6">
        <h3 className="font-bold text-green-900 mb-2">Informações Úteis</h3>
        <ul className="space-y-2 text-sm text-green-800">
          <li>• O código de área da cidade é (11)</li>
          <li>• Para ligar do exterior, use o código do país +55</li>
          <li>• Wi-Fi público disponível em praças e centros culturais</li>
          <li>• Tensão elétrica: 110V/220V - verifique antes de usar aparelhos</li>
        </ul>
      </div>
    </div>
  );
}