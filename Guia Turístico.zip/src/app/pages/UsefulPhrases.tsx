import { useState } from 'react';
import { Volume2, Copy, Check } from 'lucide-react';

export function UsefulPhrases() {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('basico');

  const categories = [
    { id: 'basico', name: 'Básico' },
    { id: 'restaurante', name: 'Restaurante' },
    { id: 'transporte', name: 'Transporte' },
    { id: 'compras', name: 'Compras' },
    { id: 'emergencia', name: 'Emergência' },
    { id: 'hotel', name: 'Hotel' },
  ];

  const phrases = {
    basico: [
      { id: '1', pt: 'Olá / Oi', en: 'Hello / Hi', pronunciation: 'heh-LOH / hai' },
      { id: '2', pt: 'Por favor', en: 'Please', pronunciation: 'pliz' },
      { id: '3', pt: 'Obrigado(a)', en: 'Thank you', pronunciation: 'THENK-yu' },
      { id: '4', pt: 'De nada', en: "You're welcome", pronunciation: 'yor WEL-kum' },
      { id: '5', pt: 'Desculpe', en: 'Excuse me / Sorry', pronunciation: 'eks-KYUZ-mi / SOR-i' },
      { id: '6', pt: 'Sim / Não', en: 'Yes / No', pronunciation: 'yes / noh' },
      { id: '7', pt: 'Você fala português?', en: 'Do you speak Portuguese?', pronunciation: 'du yu spik por-chu-GEEZ' },
      { id: '8', pt: 'Eu não entendo', en: "I don't understand", pronunciation: 'ai dont un-der-STAND' },
      { id: '9', pt: 'Quanto custa?', en: 'How much is it?', pronunciation: 'hau mutch iz it' },
      { id: '10', pt: 'Onde fica...?', en: 'Where is...?', pronunciation: 'wair iz' },
    ],
    restaurante: [
      { id: '11', pt: 'Eu gostaria de fazer uma reserva', en: "I'd like to make a reservation", pronunciation: 'aid laik tu meik a re-zer-VEI-shun' },
      { id: '12', pt: 'O cardápio, por favor', en: 'The menu, please', pronunciation: 'dhi MEN-yu pliz' },
      { id: '13', pt: 'Eu sou vegetariano(a)', en: "I'm vegetarian", pronunciation: 'aim ve-je-TAIR-i-an' },
      { id: '14', pt: 'Sem glúten, por favor', en: 'Gluten-free, please', pronunciation: 'GLU-ten-fri pliz' },
      { id: '15', pt: 'A conta, por favor', en: 'The bill, please', pronunciation: 'dhi bil pliz' },
      { id: '16', pt: 'Estava delicioso', en: 'It was delicious', pronunciation: 'it woz di-LI-shus' },
      { id: '17', pt: 'Posso ter água?', en: 'Can I have water?', pronunciation: 'ken ai hev WO-ter' },
    ],
    transporte: [
      { id: '18', pt: 'Onde fica a estação de metrô?', en: 'Where is the subway station?', pronunciation: 'wair iz dhi SUB-wei STEI-shun' },
      { id: '19', pt: 'Quanto custa o bilhete?', en: 'How much is the ticket?', pronunciation: 'hau mutch iz dhi TI-ket' },
      { id: '20', pt: 'Eu preciso ir para...', en: 'I need to go to...', pronunciation: 'ai nid tu goh tu' },
      { id: '21', pt: 'Que horas sai o próximo ônibus?', en: 'What time is the next bus?', pronunciation: 'wot taim iz dhi nekst bus' },
      { id: '22', pt: 'Você pode me levar para esse endereço?', en: 'Can you take me to this address?', pronunciation: 'ken yu teik mi tu dhis A-dres' },
      { id: '23', pt: 'Pare aqui, por favor', en: 'Stop here, please', pronunciation: 'stop hir pliz' },
    ],
    compras: [
      { id: '24', pt: 'Quanto custa isso?', en: 'How much is this?', pronunciation: 'hau mutch iz dhis' },
      { id: '25', pt: 'Posso experimentar?', en: 'Can I try this on?', pronunciation: 'ken ai trai dhis on' },
      { id: '26', pt: 'Você tem tamanho maior/menor?', en: 'Do you have a bigger/smaller size?', pronunciation: 'du yu hev a BI-ger/SMO-ler saiz' },
      { id: '27', pt: 'Vocês aceitam cartão de crédito?', en: 'Do you accept credit cards?', pronunciation: 'du yu ak-SEPT KRE-dit kards' },
      { id: '28', pt: 'Posso ter um desconto?', en: 'Can I get a discount?', pronunciation: 'ken ai get a DIS-kaunt' },
      { id: '29', pt: 'Só estou olhando', en: "I'm just looking", pronunciation: 'aim just LU-king' },
    ],
    emergencia: [
      { id: '30', pt: 'Socorro! Ajuda!', en: 'Help!', pronunciation: 'help' },
      { id: '31', pt: 'Chame a polícia', en: 'Call the police', pronunciation: 'kol dhi po-LIS' },
      { id: '32', pt: 'Preciso de um médico', en: 'I need a doctor', pronunciation: 'ai nid a DOK-tor' },
      { id: '33', pt: 'Onde fica o hospital?', en: 'Where is the hospital?', pronunciation: 'wair iz dhi HOS-pi-tal' },
      { id: '34', pt: 'Perdi meu passaporte', en: 'I lost my passport', pronunciation: 'ai lost mai PAS-port' },
      { id: '35', pt: 'Eu fui roubado(a)', en: 'I was robbed', pronunciation: 'ai woz robd' },
    ],
    hotel: [
      { id: '36', pt: 'Eu tenho uma reserva', en: 'I have a reservation', pronunciation: 'ai hev a re-zer-VEI-shun' },
      { id: '37', pt: 'Qual o horário do café da manhã?', en: 'What time is breakfast?', pronunciation: 'wot taim iz BREK-fast' },
      { id: '38', pt: 'Pode me acordar às...?', en: 'Can you wake me up at...?', pronunciation: 'ken yu weik mi up at' },
      { id: '39', pt: 'O ar condicionado não funciona', en: 'The air conditioning is not working', pronunciation: 'dhi air kun-DI-shu-ning iz not WOR-king' },
      { id: '40', pt: 'Posso ter toalhas extras?', en: 'Can I have extra towels?', pronunciation: 'ken ai hev EKS-tra TAU-els' },
      { id: '41', pt: 'Qual é a senha do Wi-Fi?', en: "What's the Wi-Fi password?", pronunciation: 'wots dhi WAI-fai PAS-word' },
    ],
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const currentPhrases = phrases[selectedCategory as keyof typeof phrases];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Frases Úteis</h1>
        <p className="text-gray-600">Aprenda expressões essenciais para se comunicar durante sua viagem</p>
      </div>

      {/* Info Card */}
      <div className="bg-green-50 rounded-lg p-4 mb-6">
        <p className="text-sm text-green-800">
          💡 <strong>Dica:</strong> Clique no ícone de som para ouvir a pronúncia ou no ícone de copiar para salvar a frase.
        </p>
      </div>

      {/* Category Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`px-4 py-2 rounded-full whitespace-nowrap transition-colors ${
              selectedCategory === category.id
                ? 'bg-green-600 text-white'
                : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
            }`}
          >
            {category.name}
          </button>
        ))}
      </div>

      {/* Phrases List */}
      <div className="space-y-3">
        {currentPhrases.map((phrase) => (
          <div
            key={phrase.id}
            className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow p-4"
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <div className="mb-2">
                  <h3 className="font-bold text-gray-900 text-lg">{phrase.pt}</h3>
                  <p className="text-gray-700">{phrase.en}</p>
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <Volume2 className="h-4 w-4 mr-1" />
                  <span className="italic">{phrase.pronunciation}</span>
                </div>
              </div>
              
              <div className="flex gap-2">
                <button
                  onClick={() => copyToClipboard(phrase.en, phrase.id)}
                  className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                  title="Copiar"
                >
                  {copiedId === phrase.id ? (
                    <Check className="h-5 w-5 text-green-600" />
                  ) : (
                    <Copy className="h-5 w-5" />
                  )}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Download Section */}
      <div className="mt-8 bg-gradient-to-r from-green-600 to-green-700 rounded-lg p-6 text-white">
        <h3 className="font-bold text-lg mb-2">Leve offline com você</h3>
        <p className="text-green-100 text-sm mb-4">
          Baixe nosso guia de frases em PDF para ter acesso mesmo sem internet.
        </p>
        <button className="px-4 py-2 bg-white text-green-600 rounded-lg hover:bg-green-50 transition-colors font-medium">
          Baixar PDF Gratuito
        </button>
      </div>
    </div>
  );
}