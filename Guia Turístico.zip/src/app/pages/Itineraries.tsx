import { useState } from 'react';
import { Clock, MapPin, DollarSign, Users, Star, ChevronDown, ChevronUp } from 'lucide-react';

export function Itineraries() {
  const [expandedItinerary, setExpandedItinerary] = useState<string | null>('1');

  const itineraries = [
    {
      id: '1',
      title: 'Centro Histórico Completo',
      duration: '1 dia',
      difficulty: 'Fácil',
      price: '$$',
      bestFor: 'História e Arquitetura',
      rating: 4.8,
      description: 'Explore os principais marcos históricos e arquitetônicos da cidade em um dia completo de caminhada.',
      stops: [
        {
          time: '9:00',
          name: 'Praça da Sé',
          duration: '45 min',
          description: 'Comece seu dia no coração histórico da cidade. Visite a catedral e aprecie a arquitetura colonial.',
          tips: 'Chegue cedo para evitar multidões',
        },
        {
          time: '10:00',
          name: 'Museu Histórico',
          duration: '1h 30min',
          description: 'Conheça a rica história da cidade através de artefatos e exposições interativas.',
          tips: 'Entrada gratuita às quartas-feiras',
        },
        {
          time: '12:00',
          name: 'Almoço no Mercado Municipal',
          duration: '1h',
          description: 'Experimente a culinária local em um dos restaurantes tradicionais do mercado.',
          tips: 'Prove o sanduíche de mortadela, especialidade local',
        },
        {
          time: '14:00',
          name: 'Theatro Municipal',
          duration: '1h',
          description: 'Tour guiado por este magnífico teatro em estilo art nouveau.',
          tips: 'Reserve o tour com antecedência online',
        },
        {
          time: '15:30',
          name: 'Rua das Flores',
          duration: '1h',
          description: 'Passeie por esta charmosa rua de pedestres com cafés e lojas artesanais.',
          tips: 'Ótimo lugar para comprar souvenirs autênticos',
        },
        {
          time: '17:00',
          name: 'Mirante do Centro',
          duration: '45 min',
          description: 'Termine o dia com uma vista panorâmica do pôr do sol sobre a cidade.',
          tips: 'Leve sua câmera para fotos incríveis',
        },
      ],
    },
    {
      id: '2',
      title: 'Arte e Cultura Moderna',
      duration: '1 dia',
      difficulty: 'Fácil',
      price: '$$$',
      bestFor: 'Arte e Museus',
      rating: 4.7,
      description: 'Mergulhe no mundo da arte contemporânea e cultura urbana com este roteiro dedicado aos amantes das artes.',
      stops: [
        {
          time: '10:00',
          name: 'Museu de Arte Moderna',
          duration: '2h',
          description: 'Explore uma das maiores coleções de arte moderna da América Latina.',
          tips: 'Não perca a exposição permanente no segundo andar',
        },
        {
          time: '12:30',
          name: 'Brunch Artístico',
          duration: '1h 30min',
          description: 'Almoço em café conceito com decoração de artistas locais.',
          tips: 'Reserve com antecedência nos fins de semana',
        },
        {
          time: '14:30',
          name: 'Galeria de Arte Contemporânea',
          duration: '1h 30min',
          description: 'Visite galerias com obras de artistas emergentes.',
          tips: 'Vernissages acontecem às quintas às 19h',
        },
        {
          time: '16:30',
          name: 'Tour de Arte de Rua',
          duration: '2h',
          description: 'Descubra os incríveis murais e grafites espalhados pela cidade.',
          tips: 'Tour guiado disponível com artistas locais',
        },
      ],
    },
    {
      id: '3',
      title: 'Natureza e Relaxamento',
      duration: '1 dia',
      difficulty: 'Moderada',
      price: '$',
      bestFor: 'Famílias e Natureza',
      rating: 4.9,
      description: 'Escape do agito urbano e desfrute dos espaços verdes e tranquilos da cidade.',
      stops: [
        {
          time: '8:00',
          name: 'Jardim Botânico',
          duration: '2h',
          description: 'Caminhe entre espécies raras de plantas e flores em um ambiente sereno.',
          tips: 'Melhor visitado pela manhã quando está mais fresco',
        },
        {
          time: '10:30',
          name: 'Café no Parque',
          duration: '45 min',
          description: 'Desfrute de um café da manhã tardio em meio à natureza.',
          tips: 'Há área de piquenique se preferir trazer sua própria comida',
        },
        {
          time: '11:30',
          name: 'Parque Ecológico',
          duration: '2h 30min',
          description: 'Trilhas leves, lago com pedalinhos e playground para crianças.',
          tips: 'Aluguel de bicicletas disponível na entrada',
        },
        {
          time: '14:30',
          name: 'Almoço Orgânico',
          duration: '1h',
          description: 'Restaurante farm-to-table com ingredientes orgânicos locais.',
          tips: 'Menu vegetariano e vegano disponível',
        },
        {
          time: '16:00',
          name: 'Parque das Esculturas',
          duration: '1h 30min',
          description: 'Museu a céu aberto com esculturas modernas em ambiente natural.',
          tips: 'Entrada gratuita e pet-friendly',
        },
      ],
    },
    {
      id: '4',
      title: 'Gastronomia Local',
      duration: '5 horas',
      difficulty: 'Fácil',
      price: '$$$$',
      bestFor: 'Foodies',
      rating: 5.0,
      description: 'Uma jornada culinária pelos melhores sabores da cidade, de comida de rua a restaurantes estrelados.',
      stops: [
        {
          time: '10:00',
          name: 'Mercado de Produtores',
          duration: '1h',
          description: 'Conheça produtores locais e prove frutas tropicais frescas.',
          tips: 'Aos sábados há degustações gratuitas',
        },
        {
          time: '11:30',
          name: 'Aula de Culinária',
          duration: '2h',
          description: 'Aprenda a preparar pratos típicos com chef local.',
          tips: 'Reserve com pelo menos 3 dias de antecedência',
        },
        {
          time: '14:00',
          name: 'Food Tour no Bairro Histórico',
          duration: '2h',
          description: 'Deguste iguarias em 5 estabelecimentos diferentes.',
          tips: 'Inclui bebidas e sobremesa',
        },
      ],
    },
  ];

  const toggleItinerary = (id: string) => {
    setExpandedItinerary(expandedItinerary === id ? null : id);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Roteiros</h1>
        <p className="text-gray-600">Roteiros cuidadosamente planejados para aproveitar ao máximo sua visita</p>
      </div>

      {/* Filter Options */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <select className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent">
            <option>Duração</option>
            <option>Meio dia</option>
            <option>1 dia</option>
            <option>2+ dias</option>
          </select>
          <select className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent">
            <option>Dificuldade</option>
            <option>Fácil</option>
            <option>Moderada</option>
            <option>Desafiadora</option>
          </select>
          <select className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent">
            <option>Preço</option>
            <option>$ (Econômico)</option>
            <option>$$ (Médio)</option>
            <option>$$$ (Alto)</option>
          </select>
          <select className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent">
            <option>Interesse</option>
            <option>História</option>
            <option>Arte</option>
            <option>Natureza</option>
            <option>Gastronomia</option>
          </select>
        </div>
      </div>

      {/* Itineraries List */}
      <div className="space-y-4">
        {itineraries.map((itinerary) => (
          <div key={itinerary.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
            {/* Itinerary Header */}
            <div
              className="p-6 cursor-pointer hover:bg-gray-50 transition-colors"
              onClick={() => toggleItinerary(itinerary.id)}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{itinerary.title}</h3>
                  <p className="text-gray-600 text-sm mb-3">{itinerary.description}</p>
                </div>
                <button className="p-1 text-gray-400 hover:text-gray-600">
                  {expandedItinerary === itinerary.id ? (
                    <ChevronUp className="h-6 w-6" />
                  ) : (
                    <ChevronDown className="h-6 w-6" />
                  )}
                </button>
              </div>

              <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-1 text-gray-400" />
                  <span>{itinerary.duration}</span>
                </div>
                <div className="flex items-center">
                  <Users className="h-4 w-4 mr-1 text-gray-400" />
                  <span>{itinerary.difficulty}</span>
                </div>
                <div className="flex items-center">
                  <DollarSign className="h-4 w-4 mr-1 text-gray-400" />
                  <span>{itinerary.price}</span>
                </div>
                <div className="flex items-center">
                  <Star className="h-4 w-4 mr-1 text-yellow-500 fill-current" />
                  <span>{itinerary.rating}</span>
                </div>
              </div>

              <div className="mt-3">
                <span className="inline-block px-3 py-1 bg-green-50 text-green-700 rounded-full text-xs">
                  {itinerary.bestFor}
                </span>
              </div>
            </div>

            {/* Itinerary Details */}
            {expandedItinerary === itinerary.id && (
              <div className="border-t border-gray-200 p-6 bg-gray-50">
                <h4 className="font-bold text-gray-900 mb-4">Paradas do Roteiro</h4>
                <div className="space-y-4">
                  {itinerary.stops.map((stop, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="flex-shrink-0">
                        <div className="w-16 text-center">
                          <span className="inline-block px-2 py-1 bg-green-600 text-white text-xs rounded font-medium">
                            {stop.time}
                          </span>
                          <div className="text-xs text-gray-500 mt-1">{stop.duration}</div>
                        </div>
                      </div>
                      <div className="flex-1 bg-white rounded-lg p-4 shadow-sm">
                        <h5 className="font-bold text-gray-900 mb-1 flex items-center">
                          <MapPin className="h-4 w-4 mr-1 text-green-600" />
                          {stop.name}
                        </h5>
                        <p className="text-sm text-gray-600 mb-2">{stop.description}</p>
                        <div className="bg-yellow-50 border-l-2 border-yellow-400 pl-3 py-1">
                          <p className="text-xs text-yellow-800">
                            <strong>Dica:</strong> {stop.tips}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 flex gap-3">
                  <button className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium">
                    Salvar Roteiro
                  </button>
                  <button className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium">
                    Imprimir PDF
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Custom Itinerary CTA */}
      <div className="mt-8 bg-gradient-to-r from-purple-600 to-green-600 rounded-lg p-6 text-white">
        <h3 className="font-bold text-lg mb-2">Precisa de um roteiro personalizado?</h3>
        <p className="text-purple-100 text-sm mb-4">
          Conte-nos seus interesses e criaremos um roteiro sob medida para sua viagem.
        </p>
        <button className="px-4 py-2 bg-white text-purple-600 rounded-lg hover:bg-purple-50 transition-colors font-medium">
          Criar Roteiro Personalizado
        </button>
      </div>
    </div>
  );
}