import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { MapPage } from "./pages/MapPage";
import { SurvivalMode } from "./pages/SurvivalMode";
import { UsefulPhrases } from "./pages/UsefulPhrases";
import { CulturalGuide } from "./pages/CulturalGuide";
import { Itineraries } from "./pages/Itineraries";
import { EventsCalendar } from "./pages/EventsCalendar";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "mapa", Component: MapPage },
      { path: "sobrevivencia", Component: SurvivalMode },
      { path: "frases", Component: UsefulPhrases },
      { path: "cultura", Component: CulturalGuide },
      { path: "roteiros", Component: Itineraries },
      { path: "eventos", Component: EventsCalendar },
    ],
  },
]);
